# Mynote by Sharad Raj Singh Maurya

>Author: Sharad Raj, GIHSM, Lucknow https://linkedin.com/in/srsm

* JDK 11.0.3
* MySQL 8.0
* CJ 8.0

### index.jsp
![index.jsp](https://raw.githubusercontent.com/sharadcodes/java_examples/master/mynote/home.png)
### detailed single note
![new.jsp](https://raw.githubusercontent.com/sharadcodes/java_examples/master/mynote/detailed%20single%20note.png)
### new note
![new.jsp](https://raw.githubusercontent.com/sharadcodes/java_examples/master/mynote/new.png)
### edit note
![edit.jsp](https://raw.githubusercontent.com/sharadcodes/java_examples/master/mynote/edit.png)
